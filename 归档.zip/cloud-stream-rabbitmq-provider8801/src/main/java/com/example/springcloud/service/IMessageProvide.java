package com.example.springcloud.service;

public interface IMessageProvide {
    String send();
}
